extends Node3D


func draw_square(x1, x2, y1, y2, z1, z2) -> Array:
	var data = []
	data.append_array([Vector3(x1, y1, z1), Vector3(x2, y2, z2), Vector3(x1, y2, z2)])
	data.append_array([Vector3(x1, y1, z1), Vector3(x1, y2, z2), Vector3(x2, y2, z2)])
	data.append_array([Vector3(x1, y1, z1), Vector3(x2, y2, z2), Vector3(x2, y2, z1)])
	data.append_array([Vector3(x1, y1, z1), Vector3(x2, y2, z1), Vector3(x2, y2, z2)])
	data.append_array([Vector3(x1, y1, z1), Vector3(x2, y2, z2), Vector3(x2, y1, z2)])
	data.append_array([Vector3(x1, y1, z1), Vector3(x2, y1, z2), Vector3(x2, y2, z2)])
	return data


func draw_cube(x, y, z) -> Array:
	if x > 0:
		x -= 1
	if y > 0:
		y -= 1
	if z  > 0:
		z -= 1
		
	var data = []
	data += draw_square(x, x+1, y, y+1, z, z)
	data += draw_square(x, x+1, y, y+1, z+1, z+1)
	data += draw_square(x, x+1, y, y, z, z+1)
	data += draw_square(x, x+1, y+1, y+1, z, z+1)
	data += draw_square(x, x, y, y+1, z, z+1)
	data += draw_square(x+1, x+1, y, y+1, z, z+1)
	return data
