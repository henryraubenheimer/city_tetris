extends Node3D


var rng = RandomNumberGenerator.new()
var current_item = 0
var current_pos = Vector3(0, 0, 0)
var occupied = []
var current_orientation = 0
var orientations = [0, 22, 10, 16]


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	current_item = rng.randi_range(0, len($GridMap.mesh_library.get_item_list())-1)
	
	$Camera3D.position = Vector3(3, 10, 5)
	$Camera3D.look_at(Vector3.ZERO)
	
	$GridMap.set_cell_item(current_pos, current_item)


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	var rotate_speed = 0
	if Input.is_action_pressed("Rotate Clockwise"):
		rotate_speed = -2
	elif Input.is_action_pressed("Rotate Counter-Clockwise"):
		rotate_speed = 2
	if rotate_speed != 0:
		var offset = $Camera3D.position - Vector3.ZERO
		var angle = rotate_speed * delta
		var rotated_offset = offset.rotated(Vector3.UP, angle)
		$Camera3D.position = Vector3.ZERO + rotated_offset
		$Camera3D.look_at(Vector3.ZERO)
		
	if Input.is_action_just_pressed("Forward"):
		move_current_pos(Vector3(0, 0, -1))
	elif Input.is_action_just_pressed("Backward"):
		move_current_pos(Vector3(0, 0, 1))
	elif Input.is_action_just_pressed("Left"):
		move_current_pos(Vector3(-1, 0, 0))
	elif Input.is_action_just_pressed("Right"):
		move_current_pos(Vector3(1, 0, 0))
		
	if Input.is_action_just_pressed("Rotate Piece"):
		if current_pos not in occupied:
			current_orientation += 1
			$GridMap.set_cell_item(current_pos, current_item, orientations[current_orientation%4])
		
	if Input.is_action_just_pressed("Place"):
		occupied.append(current_pos)
		current_item = rng.randi_range(0, len($GridMap.mesh_library.get_item_list())-1)


func move_current_pos(pos_delta: Vector3):
	if current_pos not in occupied:
		$GridMap.set_cell_item(current_pos, -1)
	current_pos += pos_delta
	if current_pos not in occupied:
		$GridMap.set_cell_item(current_pos, current_item, orientations[current_orientation%4])
