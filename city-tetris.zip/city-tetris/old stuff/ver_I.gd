@tool
extends MeshInstance3D

var mesh_data = []

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	mesh_data.resize(ArrayMesh.ARRAY_MAX)
	mesh_data[ArrayMesh.ARRAY_VERTEX] = PackedVector3Array()
	mesh = ArrayMesh.new()
	
	draw_cube(1, -1, 1)
	draw_cube(1, 1, 1)
	draw_cube(1, 2, 1)
	
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, mesh_data)
	

func draw_square(x1, x2, y1, y2, z1, z2):
	mesh_data[ArrayMesh.ARRAY_VERTEX].append_array([Vector3(x1, y1, z1), Vector3(x2, y2, z2), Vector3(x1, y2, z2)])
	mesh_data[ArrayMesh.ARRAY_VERTEX].append_array([Vector3(x1, y1, z1), Vector3(x1, y2, z2), Vector3(x2, y2, z2)])
	mesh_data[ArrayMesh.ARRAY_VERTEX].append_array([Vector3(x1, y1, z1), Vector3(x2, y2, z2), Vector3(x2, y2, z1)])
	mesh_data[ArrayMesh.ARRAY_VERTEX].append_array([Vector3(x1, y1, z1), Vector3(x2, y2, z1), Vector3(x2, y2, z2)])
	mesh_data[ArrayMesh.ARRAY_VERTEX].append_array([Vector3(x1, y1, z1), Vector3(x2, y2, z2), Vector3(x2, y1, z2)])
	mesh_data[ArrayMesh.ARRAY_VERTEX].append_array([Vector3(x1, y1, z1), Vector3(x2, y1, z2), Vector3(x2, y2, z2)])


func draw_cube(x, y, z):
	if x > 0:
		x -= 1
	if y > 0:
		y -= 1
	if z  > 0:
		z -= 1
		
	draw_square(x, x+1, y, y+1, z, z)
	draw_square(x, x+1, y, y+1, z+1, z+1)
	draw_square(x, x+1, y, y, z, z+1)
	draw_square(x, x+1, y+1, y+1, z, z+1)
	draw_square(x, x, y, y+1, z, z+1)
	draw_square(x+1, x+1, y, y+1, z, z+1)


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass
