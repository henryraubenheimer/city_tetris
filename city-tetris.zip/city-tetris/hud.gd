extends CanvasLayer


var score = 0
var pending_score = 0
var turn = 0
var turn_limit = "∞"


func update_score(s: int):
	score = s
	$Score.text = str(score) + " + " + str(pending_score)
	
func update_pending_score(ps: int):
	pending_score = ps
	$Score.text = str(score) + " + " + str(pending_score)
	
func update_turn(t: int):
	turn = t
	$Turn.text = str(turn) + " / " + turn_limit
	
func update_turn_limit(tl: int):
	if tl == INF:
		turn_limit = "∞"
	else:
		turn_limit = str(tl)
	$Turn.text = str(turn) + " / " + turn_limit

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass
