extends Node3D

# Configuration Constants
const CAMERA_ROTATE_SPEED = 2.0
const CAMERA_START_POS = Vector3(3, 10, 5)
const CAMERA_LOOK_AT = Vector3.ZERO

# State variables
var rng = RandomNumberGenerator.new()
var streams: Array[int]
var current_pos := Vector3.ZERO
var orientation := 0
var occupied_cells := {}  # Dictionary used as a Set for O(1) lookup
var score := 0
var current_stream := 0
var piece_types: Array
var turn := 0


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	var gamemode = 5
	
	#var floor_range = 40
	#for x in range(-floor_range, floor_range):
		#for z in range(-floor_range, floor_range):
			#$GridMap.set_cell_item(Vector3(x, -1, z), 2)
	#$GridMap.set_cell_item(Vector3(5, 0, 0), 2)
	
	$HUD.update_turn_limit(3*4*5/gamemode)
	
	if gamemode == 3:
		piece_types = shapes.get_tricubes()
	elif gamemode == 4:
		piece_types = shapes.get_tetracubes()
	elif gamemode == 5:
		piece_types = shapes.get_pentacubes()
	
	$Camera3D.position = CAMERA_START_POS
	$Camera3D.look_at(CAMERA_LOOK_AT)
	
	for i in range(3):
		streams.append(rng.randi_range(0, len(piece_types) - 1))
	
	_spawn_new_piece()

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	_handle_camera_rotation(delta)
	_handle_piece_stream()
	_handle_piece_movement()
	_handle_piece_rotation()
	
	$HUD.update_pending_score(_calculate_score_boost(_get_piece_coordinates(current_pos, orientation)))
	
	_handle_piece_placement()
	_render_current_piece()
	#
#### cell information functions
	#
func _can_place_piece() -> bool:
	var coords := _get_piece_coordinates(current_pos, orientation)
	
	for coord in coords:
		if coord in occupied_cells:
			return false
	
	return true
	
func _has_support_below() -> bool:
	var coords := _get_piece_coordinates(current_pos, orientation)
	
	for coord in coords:
		# If at ground level (y=0), it's supported
		if coord.y == 0:
			continue
		
		# Check if there's an occupied cell OR another part of this piece directly below
		var cell_below := Vector3(coord.x, coord.y - 1, coord.z)
		if cell_below not in occupied_cells and cell_below not in coords:
			return false
	
	return true
	
func _get_piece_coordinates(pos: Vector3, rot: int) -> Array[Vector3]:
	var base_coords = piece_types[streams[current_stream]].duplicate()
	base_coords.append(Vector3.ZERO)
	for i in range(rot%4):
		base_coords = shapes.rotate_y(base_coords)
	var world_coords: Array[Vector3] = []
	
	for coord in base_coords:
		world_coords.append(pos + coord)
	
	return world_coords
	
func _calculate_score_boost(coords) -> int:
	var adjacent_offsets := [
		Vector3(1, 0, 0),   # right
		Vector3(-1, 0, 0),  # left
		Vector3(0, 1, 0),   # up
		Vector3(0, -1, 0),  # down
		Vector3(0, 0, 1),   # back
		Vector3(0, 0, -1)   # forward
	]	
	
	var occupied_cells_copy = occupied_cells.duplicate()
	
	var boost = 0
	for coord in coords:
		for offset in adjacent_offsets:
			var neighbor = coord + offset
			if neighbor in occupied_cells_copy:
				boost += 1
		occupied_cells_copy[coord] = true
	
	return boost
	
#### current piece operator functions
	
func _spawn_new_piece() -> void:
	streams[current_stream] = rng.randi_range(0, len(piece_types) - 1)
	orientation = 0
	while current_pos in occupied_cells:
		current_pos.y += 1
	$GridMap.set_cell_item(current_pos, 1)
		#
func _place_current_piece() -> void:
	var coords := _get_piece_coordinates(current_pos, orientation)
	
	score += _calculate_score_boost(coords)
	for coord in coords:				
		$GridMap.set_cell_item(coord, 0)
		occupied_cells[coord] = true
	
	$HUD.update_score(score)
	
	turn += 1
	$HUD.update_turn(turn)
	
func _clear_piece_from_grid() -> void:
	var coords := _get_piece_coordinates(current_pos, orientation)
	
	for coord in coords:
		if coord in occupied_cells:
			$GridMap.set_cell_item(coord, 0)  # Restore occupied cell
		else:
			$GridMap.set_cell_item(coord, -1)  # Clear empty cell
	
### _process functions

func _handle_camera_rotation(delta: float) -> void:
	var rotate_direction := 0.0
	
	if Input.is_action_pressed("Rotate Clockwise"):
		rotate_direction = -1.0
	elif Input.is_action_pressed("Rotate Counter-Clockwise"):
		rotate_direction = 1.0
	
	if rotate_direction != 0:
		var offset = $Camera3D.position - CAMERA_LOOK_AT
		var rotated_offset = offset.rotated(Vector3.UP, rotate_direction * CAMERA_ROTATE_SPEED * delta)
		$Camera3D.position = CAMERA_LOOK_AT + rotated_offset
		$Camera3D.look_at(CAMERA_LOOK_AT)
		
func _handle_piece_stream() -> void:
	_clear_piece_from_grid()
	if Input.is_action_just_pressed("Stream 1"):
		current_stream = 0
	elif Input.is_action_just_pressed("Stream 2"):
		current_stream = 1
	elif Input.is_action_just_pressed("Stream 3"):
		current_stream = 2
		
func _handle_piece_movement() -> void:
	var move_delta := Vector3.ZERO
	
	# Get camera's direction (normalized for safety)
	var cam_pos = $Camera3D.position.normalized()

	# Determine primary axis (which axis camera is most aligned with)
	var forward = Vector3.ZERO
	if abs(cam_pos.x) < abs(cam_pos.z):
		# Camera more aligned with Z axis
		forward = Vector3(0, 0, -sign(cam_pos.z))
	else:
		# Camera more aligned with X axis
		forward = Vector3(-sign(cam_pos.x), 0, 0)

	# Derive other directions
	var backward = -forward
	var right = Vector3(-forward.z, 0, forward.x)  # Rotate forward 90° clockwise
	var left = -right

	# Apply based on input
	if Input.is_action_just_pressed("Forward"):
		move_delta = forward
	elif Input.is_action_just_pressed("Backward"):
		move_delta = backward
	elif Input.is_action_just_pressed("Left"):
		move_delta = left
	elif Input.is_action_just_pressed("Right"):
		move_delta = right
	
	if move_delta != Vector3.ZERO:
		_clear_piece_from_grid()
		current_pos += move_delta
		
		while current_pos in occupied_cells:
			current_pos += Vector3(0, 1, 0)
			
		while current_pos[1] > 0 and ((current_pos - Vector3(0, 1, 0)) not in occupied_cells):
			current_pos -= Vector3(0, 1, 0)
			
func _handle_piece_rotation() -> void:
	if Input.is_action_just_pressed("Rotate Piece"):
		_clear_piece_from_grid()
		orientation += 1
	
func _handle_piece_placement() -> void:
	if not Input.is_action_just_pressed("Place"):
		return
	
	if _can_place_piece() and _has_support_below():
		_place_current_piece()
		_spawn_new_piece()
		
func _render_current_piece() -> void:
	var coords := _get_piece_coordinates(current_pos, orientation)
	
	for coord in coords:
		$GridMap.set_cell_item(coord, 1)
