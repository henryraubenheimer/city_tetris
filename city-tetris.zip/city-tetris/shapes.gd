class_name shapes


static func get_tricubes():
	
	var I = [Vector3(-1, 0, 0), Vector3(1, 0, 0)]
	var L = [Vector3(1, 0, 0), Vector3(0, 0, 1)]
	var collection = [I, L]

	return find_permutations(collection)
	
	
static func get_tetracubes():
	
	var I = [Vector3(-1, 0, 0), Vector3(1, 0, 0), Vector3(2, 0, 0)]
	var L = [Vector3(1, 0, 0), Vector3(0, 0, 1), Vector3(0, 0, 2)]
	var O = [Vector3(1, 0, 0), Vector3(0, 0, 1), Vector3(1, 0, 1)]
	var T = [Vector3(-1, 0, 0), Vector3(0, 0, 1), Vector3(1, 0, 0)]
	var Z = [Vector3(1, 0, 0), Vector3(0, 0, 1), Vector3(-1, 0, 1)]
	var L3 = [Vector3(1, 0, 0), Vector3(0, 1, 0), Vector3(0, 0, 1)]
	var Z31 = [Vector3(1, 0, 0), Vector3(0, 0, 1), Vector3(0, 1, 1)]
	var Z32 = [Vector3(-1, 0, 0), Vector3(0, 0, 1), Vector3(0, 1, 1)]
	var collection = [I, L, O, T, Z, L3, Z31, Z32]

	return find_permutations(collection)
	
	
static func get_pentacubes():
	
	var F = [Vector3(-1, 0, 0), Vector3(0, 0, -1), Vector3(0, 0, 1), Vector3(1, 0, 1)]
	var I = [Vector3(-2, 0, 0), Vector3(-1, 0, 0), Vector3(1, 0, 0), Vector3(2, 0, 0)]
	var L = [Vector3(-1, 0, 0), Vector3(0, 0, 1), Vector3(0, 0, 2), Vector3(0, 0, 3)]
	var P = [Vector3(-1, 0, 0), Vector3(0, 0, 1), Vector3(1, 0, 0), Vector3(1, 0, 1)]
	var N = [Vector3(-1, 0, 1), Vector3(0, 0, 1), Vector3(1, 0, 0), Vector3(2, 0, 0)]
	var T = [Vector3(-2, 0, 0), Vector3(-1, 0, 0), Vector3(0, 0, -1), Vector3(0, 0, 1)]
	var U = [Vector3(1, 0, -1), Vector3(0, 0, -1), Vector3(0, 0, 1), Vector3(1, 0, 1)]
	var V = [Vector3(1, 0, 0), Vector3(2, 0, 0), Vector3(0, 0, 1), Vector3(0, 0, 2)]
	var W = [Vector3(-1, 0, 0), Vector3(-1, 0, 1), Vector3(0, 0, -1), Vector3(1, 0, -1)]
	var X = [Vector3(-1, 0, 0), Vector3(0, 0, -1), Vector3(1, 0, 0), Vector3(0, 0, 1)]
	var Y = [Vector3(-2, 0, 0), Vector3(-1, 0, 0), Vector3(0, 0, -1), Vector3(1, 0, 0)]
	var Z = [Vector3(-1, 0, 0), Vector3(-1, 0, 1), Vector3(1, 0, 0), Vector3(1, 0, -1)]
	var J1 = [Vector3(0, 0, -1), Vector3(1, 0, 0), Vector3(2, 0, 0), Vector3(2, 1, 0)]
	var J2 = [Vector3(0, 0, -1), Vector3(1, 0, 0), Vector3(2, 0, 0), Vector3(1, 1, 0)]
	var J4 = [Vector3(0, 0, -1), Vector3(1, 0, 0), Vector3(2, 0, 0), Vector3(0, 1, -1)]
	var L1 = [Vector3(0, 0, 1), Vector3(1, 0, 0), Vector3(2, 0, 0), Vector3(2, 1, 0)]
	var L2 = [Vector3(0, 0, 1), Vector3(1, 0, 0), Vector3(2, 0, 0), Vector3(1, 1, 0)]
	var L3 = [Vector3(0, 0, 1), Vector3(1, 0, 0), Vector3(2, 0, 0), Vector3(0, 1, 0)]
	var L4 = [Vector3(0, 0, 1), Vector3(1, 0, 0), Vector3(2, 0, 0), Vector3(0, 1, 1)]
	var N1 = [Vector3(0, 0, -1), Vector3(1, 0, -1), Vector3(-1, 0, 0), Vector3(1, 1, -1)]
	var N2 = [Vector3(0, 0, -1), Vector3(1, 0, -1), Vector3(-1, 0, 0), Vector3(0, 1, -1)]
	var S1 = [Vector3(0, 0, -1), Vector3(-1, 0, -1), Vector3(1, 0, 0), Vector3(-1, 1, -1)]
	var S2 = [Vector3(0, 0, -1), Vector3(-1, 0, -1), Vector3(1, 0, 0), Vector3(0, 1, -1)]
	var T1 = [Vector3(-1, 0, 0), Vector3(0, 0, -1), Vector3(0, 0, 1), Vector3(0, 1, 0)]
	var T2 = [Vector3(-1, 0, 0), Vector3(0, 0, -1), Vector3(0, 0, 1), Vector3(-1, 1, 0)]
	var V1 = [Vector3(-1, 0, 0), Vector3(-1, 0, 1), Vector3(0, 1, 0), Vector3(0, 1, -1)]
	var V2 = [Vector3(-1, 0, 0), Vector3(-1, 0, -1), Vector3(0, 1, 0), Vector3(0, 1, 1)]
	var A = [Vector3(1, 0, 0), Vector3(1, 1, 0), Vector3(0, 0, 1), Vector3(0, 1, 1)]
	var Q = [Vector3(1, 0, 0), Vector3(0, 0, 1), Vector3(1, 0, 1), Vector3(0, 1, 0)]
	var collection = [F, I, L, P, N, T, U, V, W, X, Y, Z, J1, J2, J4, L1, L2, L3, L4, N1, N2, S1, S2, T1, T2, V1, V2, A, Q]
	
	return find_permutations(collection)
	
	
static func get_level_1():
	
	return [Vector3(1, 0, 1), 
		Vector3(1, 0, 0), 
		Vector3(1, 0, -1), 
		Vector3(0, 0, -1), 
		Vector3(-1, 0, -1),
		Vector3(-1, 0, 0),
		Vector3(-1, 0, 1),
		Vector3(0, 0, 1),
		Vector3.ZERO]
	
	
static func find_permutations(collection):
	var new_collection = collection.duplicate(true)
	for shape in collection:
		var new_shape = shape.duplicate()
		for z in range(4):
			new_shape = rotate_z(new_shape)
			var unique = true
			for y in range(4):
				new_shape = rotate_y(new_shape)
				# Check if new_shape already exists in new_collection
				if is_shape_in_collection(new_shape, new_collection):
					unique = false
			if unique and not defying_gravity(new_shape):
				new_collection.append(new_shape.duplicate())
		for x in range(4):
			new_shape = rotate_x(new_shape)
			var unique = true
			for y in range(4):
				new_shape = rotate_y(new_shape)
				# Check if new_shape already exists in new_collection
				if is_shape_in_collection(new_shape, new_collection):
					unique = false
			if unique and not defying_gravity(new_shape):
				new_collection.append(new_shape.duplicate())
				
	for i in range(len(new_collection)):
		new_collection[i] += [Vector3.ZERO]
		
		var min_y = 0
		for j in range(len(new_collection[i])):
			if new_collection[i][j].y < min_y:
				min_y = new_collection[i][j].y
	
		for j in range(new_collection[i].size()): # ground everything
			new_collection[i][j].y -= min_y
			
		var offset = Vector3(len(new_collection), 0, len(new_collection))
		for j in range(new_collection[i].size()):
			if new_collection[i][j].length() < offset.length() and new_collection[i][j].y == 0:
				offset = new_collection[i][j]
				
		for j in range(new_collection[i].size()):
			new_collection[i][j].x -= offset.x
			new_collection[i][j].z -= offset.z
			
		new_collection[i].erase(Vector3.ZERO)
				
	return new_collection
	

# Helper function to check if a shape is defying gravity or not
static func defying_gravity(shape):
	for coord in shape:
		var hanging = false
		for i in range(len(shape)):
			if Vector3(coord.x, coord.y-i-1, coord.z) in shape:
				if hanging:
					return true
				else:
					break
			else:
				hanging = true
			
	return false
	

# Helper function to check if a shape exists in the collection
static func is_shape_in_collection(shape, collection):
	for existing_shape in collection:
		if shapes_equal(shape, existing_shape):
			return true
	return false

# Helper function to check if two shapes are equal (same vectors, order-independent)
static func shapes_equal(shape1, shape2):
	if shape1.size() != shape2.size():
		return false
	
	# Convert to dictionaries to check set equality
	var dict1 = {}
	var dict2 = {}
	
	for vec in shape1:
		dict1[vec] = true
	for vec in shape2:
		dict2[vec] = true
	
	# Check if all keys match
	if dict1.size() != dict2.size():
		return false
	
	for vec in dict1.keys():
		if not vec in dict2:
			return false
	
	return true
	
	
static func assert_all_connected(shape: Array):
	# Add the implicit origin point
	var points = [Vector3.ZERO] + shape
	
	# Check that each point has at least one adjacent point
	for point in points:
		var has_adjacent = false
		
		for other_point in points:
			if point == other_point:
				continue
			
			var diff = (point - other_point).abs()
			
			# Check if adjacent (differs by 1 on exactly one axis)
			var non_zero_axes = 0
			if diff.x > 0:
				non_zero_axes += 1
			if diff.y > 0:
				non_zero_axes += 1
			if diff.z > 0:
				non_zero_axes += 1
			
			# Adjacent means exactly one axis differs by exactly 1
			if non_zero_axes == 1 and max(diff.x, max(diff.y, diff.z)) == 1:
				has_adjacent = true
				break
		
		if not has_adjacent:
			push_error("Point %s has no adjacent points" % point)
			return false
			
	return true
	

static func rotate_x(shape):
	
	for i in range(len(shape)):
		shape[i] = shape[i].rotated(Vector3(1, 0, 0), PI / 2).round()
		
	return shape
	
	
static func rotate_z(shape):
	
	for i in range(len(shape)):
		shape[i] = shape[i].rotated(Vector3(0, 0, 1), PI / 2).round()
		
	return shape
	
	
static func rotate_y(shape):
	
	for i in range(len(shape)):
		shape[i] = shape[i].rotated(Vector3(0, 1, 0), PI / 2).round()
		
	return shape
