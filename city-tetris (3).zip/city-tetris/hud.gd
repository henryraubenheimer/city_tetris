extends CanvasLayer


var score = 0
var pending_score = 0
var turn = 0
var turn_limit = "∞"
var storage = 0
var max_utility = 1
var max_storage = 1
var used_utilities = 0


func update_score(s: int):
	score = s
	$Score.text = str(score) + " + " + str(pending_score)
	
func update_pending_score(ps: int):
	pending_score = ps
	$Score.text = str(score) + " + " + str(pending_score)
	
func update_turn(t: int):
	turn = t
	$Turn.text = str(turn) + " / " + turn_limit
	
func update_turn_limit(tl: int):
	if tl == INF:
		turn_limit = "∞"
	else:
		turn_limit = str(tl)
	$Turn.text = str(turn) + " / " + turn_limit
	
func update_options(store=0, current=1, utility=used_utilities, ms=max_storage, mu=max_utility):
	current -= 1
	storage = store
	used_utilities = utility
	max_storage = ms
	max_utility = mu
	
	var options = ["[1] Piece 1", "[2] Piece 2", "[3] Piece 3", "[4] Storage ("+str(storage)+"/"+str(ms)+")", "[5] Utility ("+str(utility)+"/"+str(mu)+")"]
	var str = ""
	
	for i in range(len(options)):
		if i == current:
			str += "[b]"
		str += options[i]
		if i == current:
			str += "[/b]"
		str += "\n"
	
	$Options.text = str

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass
