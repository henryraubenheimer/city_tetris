class_name levels


# 4x4 floor
static func get_level_1():
	
	var landscape = []
	var floor_range = 4
	for x in range(-floor_range, floor_range):
		for z in range(-floor_range, floor_range):
			landscape.append(Vector3(x, -1, z))
	return landscape
	
# Hill
static func get_level_2():
	
	var landscape = []
	
	var floor_range = 4
	
	landscape.append(Vector3(0, 2, 0))
	landscape.append(Vector3(0, 2, -1))
	landscape.append(Vector3(-1, 2, 0))
	landscape.append(Vector3(-1, 2, -1))
	landscape.append(Vector3(1, 1, 0))
	landscape.append(Vector3(1, 1, -1))
	landscape.append(Vector3(0, 1, 1))
	landscape.append(Vector3(-1, 1, 1))
	landscape.append(Vector3(-2, 1, 0))
	landscape.append(Vector3(-2, 1, -1))
	landscape.append(Vector3(0, 1, -2))
	landscape.append(Vector3(-1, 1, -2))
	landscape.append(Vector3(2, 0, 0))
	landscape.append(Vector3(2, 0, -1))
	landscape.append(Vector3(1, 0, 1))
	landscape.append(Vector3(-2, 0, 1))
	landscape.append(Vector3(0, 0, 2))
	landscape.append(Vector3(-1, 0, 2))
	landscape.append(Vector3(-3, 0, 0))
	landscape.append(Vector3(-3, 0, -1))
	landscape.append(Vector3(0, 0, -3))
	landscape.append(Vector3(-1, 0, -3))
	landscape.append(Vector3(1, 0, -2))
	landscape.append(Vector3(-2, 0, -2))
	landscape.append(Vector3(3, -1, 0))
	landscape.append(Vector3(3, -1, -1))
	landscape.append(Vector3(2, -1, 1))
	landscape.append(Vector3(1, -1, 2))
	landscape.append(Vector3(0, -1, 3))
	landscape.append(Vector3(-1, -1, 3))
	landscape.append(Vector3(-2, -1, 2))
	landscape.append(Vector3(-3, -1, 1))
	landscape.append(Vector3(-4, -1, 0))
	landscape.append(Vector3(-4, -1, -1))
	landscape.append(Vector3(-3, -1, -2))
	landscape.append(Vector3(-2, -1, -3))
	landscape.append(Vector3(-1, -1, -4))
	landscape.append(Vector3(0, -1, -4))
	landscape.append(Vector3(1, -1, -3))
	landscape.append(Vector3(2, -1, -2))
	
	return landscape

# Valley
static func get_level_3():
	
	var landscape = []
	
	landscape.append(Vector3(0, -1, 0))
	landscape.append(Vector3(0, -1, -1))
	landscape.append(Vector3(-1, -1, 0))
	landscape.append(Vector3(-1, -1, -1))
	landscape.append(Vector3(1, 0, 0))
	landscape.append(Vector3(1, 0, -1))
	landscape.append(Vector3(0, 0, 1))
	landscape.append(Vector3(-1, 0, 1))
	landscape.append(Vector3(-2, 0, 0))
	landscape.append(Vector3(-2, 0, -1))
	landscape.append(Vector3(0, 0, -2))
	landscape.append(Vector3(-1, 0, -2))
	landscape.append(Vector3(2, 1, 0))
	landscape.append(Vector3(2, 1, -1))
	landscape.append(Vector3(1, 1, 1))
	landscape.append(Vector3(-2, 1, 1))
	landscape.append(Vector3(0, 1, 2))
	landscape.append(Vector3(-1, 1, 2))
	landscape.append(Vector3(-3, 1, 0))
	landscape.append(Vector3(-3, 1, -1))
	landscape.append(Vector3(0, 1, -3))
	landscape.append(Vector3(-1, 1, -3))
	landscape.append(Vector3(1, 1, -2))
	landscape.append(Vector3(-2, 1, -2))
	landscape.append(Vector3(3, 2, 0))
	landscape.append(Vector3(3, 2, -1))
	landscape.append(Vector3(2, 2, 1))
	landscape.append(Vector3(1, 2, 2))
	landscape.append(Vector3(0, 2, 3))
	landscape.append(Vector3(-1, 2, 3))
	landscape.append(Vector3(-2, 2, 2))
	landscape.append(Vector3(-3, 2, 1))
	landscape.append(Vector3(-4, 2, 0))
	landscape.append(Vector3(-4, 2, -1))
	landscape.append(Vector3(-3, 2, -2))
	landscape.append(Vector3(-2, 2, -3))
	landscape.append(Vector3(-1, 2, -4))
	landscape.append(Vector3(0, 2, -4))
	landscape.append(Vector3(1, 2, -3))
	landscape.append(Vector3(2, 2, -2))
	
	return landscape

# Stripper Pole
static func get_level_4():
	
	var landscape = []
	
	var floor_range = 3
	for x in range(-floor_range, floor_range):
		for z in range(-floor_range, floor_range):
			landscape.append(Vector3(x, -1, z))
	for i in range(-2, 3):
		landscape.append(Vector3(i, -1, 3))		
		landscape.append(Vector3(3, -1, i))	
	
	landscape.erase(Vector3(-3, -1, -3))
	
	landscape.append(Vector3(0, 0, 0))		
	landscape.append(Vector3(0, 1, 0))	
	landscape.append(Vector3(0, 2, 0))
	landscape.append(Vector3(0, 3, 0))	
	
	landscape.append(Vector3(1, 0, 0))
	landscape.append(Vector3(-1, 0, 0))
	landscape.append(Vector3(0, 0, -1))
	landscape.append(Vector3(0, 0, 1))	
			
	return landscape

# Slant
static func get_level_5():
	
	var landscape = []
	
	var floor_range = 4
	for i in range(-floor_range, floor_range):
		for z in range(-floor_range, floor_range):
			landscape.append(Vector3(i, floor_range+i, z))
			
	return landscape
	
# Stretched Slant
static func get_level_6():
	
	var landscape = []
	
	var floor_range = 3
	for i in range(-floor_range, floor_range):
		for z in range(-2*floor_range, 2*floor_range):
			landscape.append(Vector3(2*i, floor_range+i, z))
			landscape.append(Vector3(2*i+1, floor_range+i, z))
			
	return landscape	

# Checkered Floor
static func get_level_7():
	
	var landscape = []
	
	var floor_range = 3
	for x in range(-floor_range, floor_range):
		for z in range(-floor_range, floor_range):
			if (x+z) % 2 == 0:
				landscape.append(Vector3(x, 0, z))
			else:
				landscape.append(Vector3(x, -1, z))
			
	return landscape
