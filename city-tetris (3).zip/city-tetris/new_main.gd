extends Node3D

# Configuration Constants
const CAMERA_ROTATE_SPEED = 2.0
const CAMERA_START_POS = Vector3(3, 10, 5)
const CAMERA_LOOK_AT = Vector3.ZERO
const STACK_CAPACITY = 1
const MAX_UTILITES = 1

# State variables
var rng = RandomNumberGenerator.new()
var streams: Array[int]
var current_pos := Vector3.ZERO
var orientation := 0
var occupied_cells := {}  # Dictionary used as a Set for O(1) lookup
var score := 0
var current_stream := 0
var piece_types: Array
var turn := 0
var stack = []
var using_stack_piece := false
var using_utility := false
var utility_usage = 0

enum {LAND, PP, CP, UT}

var land_cells := {}


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	var gamemode = 4
	var level = 1
	
	$HUD.update_options(0, 1, 0, STACK_CAPACITY, MAX_UTILITES)
	
	var landscape = []
	if level == 1:
		landscape = levels.get_level_1()
	if level == 2:
		landscape = levels.get_level_2()
	if level == 3:
		landscape = levels.get_level_3()
	if level == 4:
		landscape = levels.get_level_4()
	if level == 5:
		landscape = levels.get_level_5()
	if level == 6:
		landscape = levels.get_level_6()
	if level == 7:
		landscape = levels.get_level_7()
		
	for item in landscape:
		$GridMap.set_cell_item(item, LAND)
		land_cells[item] = true
	
	$HUD.update_turn_limit(3*4*5/gamemode)
	
	if gamemode == 3:
		piece_types = shapes.get_tricubes()
	elif gamemode == 4:
		piece_types = shapes.get_tetracubes()
	elif gamemode == 5:
		piece_types = shapes.get_pentacubes()
	
	$Camera3D.position = CAMERA_START_POS
	$Camera3D.look_at(CAMERA_LOOK_AT)
	
	for i in range(3):
		streams.append(rng.randi_range(0, len(piece_types) - 1))
	
	_spawn_new_piece()

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	_handle_camera_rotation(delta)
	_handle_piece_stream()
	_handle_piece_movement()
	_handle_piece_rotation()
	
	$HUD.update_pending_score(_calculate_score_boost(_get_piece_coordinates(current_pos, orientation)))
	
	_handle_piece_placement()
	_render_current_piece()
	
#### cell information functions
	
func _can_place_piece() -> bool:
	var coords := _get_piece_coordinates(current_pos, orientation)
	
	for coord in coords:
		if coord in occupied_cells:
			return false
		# Also check if the cell is a LAND block
		if $GridMap.get_cell_item(coord) == LAND:
			return false
	
	return true
	
func _has_support_below() -> bool:
	var coords := _get_piece_coordinates(current_pos, orientation)
	
	for coord in coords:
		var cell_below := Vector3(coord.x, coord.y - 1, coord.z)
		var cell_below_type = $GridMap.get_cell_item(cell_below)
		# Supported if the cell below is LAND, a placed piece, or another part of this piece
		if cell_below_type == LAND or cell_below_type == PP or cell_below in coords:
			continue
		return false
	
	return true
	
func _get_piece_coordinates(pos: Vector3, rot: int) -> Array[Vector3]:
	if using_utility:
		return [pos]
	
	var piece_index: int
	if using_stack_piece:
		piece_index = stack.back()
	else:
		piece_index = streams[current_stream]
	
	var base_coords = piece_types[piece_index].duplicate()
	base_coords.append(Vector3.ZERO)
	for i in range(rot % 4):
		base_coords = shapes.rotate_y(base_coords)
	var world_coords: Array[Vector3] = []
	
	for coord in base_coords:
		world_coords.append(pos + coord)
	
	return world_coords
	
func _calculate_score_boost(coords) -> int:
	var adjacent_offsets := [
		Vector3(1, 0, 0),   # right
		Vector3(-1, 0, 0),  # left
		Vector3(0, 1, 0),   # up
		Vector3(0, -1, 0),  # down
		Vector3(0, 0, 1),   # back
		Vector3(0, 0, -1)   # forward
	]	
	
	var occupied_cells_copy = occupied_cells.duplicate()
	
	var boost = 0
	for coord in coords:
		for offset in adjacent_offsets:
			var neighbor = coord + offset
			if neighbor in occupied_cells_copy:
				boost += 1
		occupied_cells_copy[coord] = true
	
	return boost
	
#### current piece operator functions
	
func _spawn_new_piece() -> void:
	streams[current_stream] = rng.randi_range(0, len(piece_types) - 1)
	orientation = 0
	while (current_pos in occupied_cells or $GridMap.get_cell_item(current_pos) == LAND) or $GridMap.get_cell_item(current_pos-Vector3(0, 1, 0)) not in [LAND, PP]:
		current_pos.y += 1
	$GridMap.set_cell_item(current_pos, CP)
		
func _place_current_piece() -> void:
	var coords := _get_piece_coordinates(current_pos, orientation)
	
	score += _calculate_score_boost(coords)
	for coord in coords:				
		$GridMap.set_cell_item(coord, PP)
		occupied_cells[coord] = true
		if coord.y > $Camera3D.position.y-6:
			$Camera3D.position.y = coord.y+6
	
	$HUD.update_score(score)
	
	turn += 1
	$HUD.update_turn(turn)
			
func _clear_piece_from_grid() -> void:
	var coords := _get_piece_coordinates(current_pos, orientation)
	
	for coord in coords:
		if coord in occupied_cells:
			$GridMap.set_cell_item(coord, PP)
		elif coord in land_cells:
			$GridMap.set_cell_item(coord, LAND)
		else:
			$GridMap.set_cell_item(coord, -1)
	
### _process functions

func _handle_camera_rotation(delta: float) -> void:
	var rotate_direction := 0.0
	
	if Input.is_action_pressed("Rotate Clockwise"):
		rotate_direction = -1.0
	elif Input.is_action_pressed("Rotate Counter-Clockwise"):
		rotate_direction = 1.0
	
	if rotate_direction != 0:
		var offset = $Camera3D.position - CAMERA_LOOK_AT
		var rotated_offset = offset.rotated(Vector3.UP, rotate_direction * CAMERA_ROTATE_SPEED * delta)
		$Camera3D.position = CAMERA_LOOK_AT + rotated_offset
		$Camera3D.look_at(CAMERA_LOOK_AT)
			
func _handle_piece_stream() -> void:
	_clear_piece_from_grid()
	if Input.is_action_just_pressed("Stream 1"):
		current_stream = 0
		using_stack_piece = false
		using_utility = false
		$HUD.update_options(len(stack), 1)
	elif Input.is_action_just_pressed("Stream 2"):
		current_stream = 1
		using_stack_piece = false
		using_utility = false
		$HUD.update_options(len(stack), 2)
	elif Input.is_action_just_pressed("Stream 3"):
		current_stream = 2
		using_stack_piece = false
		using_utility = false
		$HUD.update_options(len(stack), 3)
	elif Input.is_action_just_pressed("Store"):
		if stack.size() < STACK_CAPACITY:
			stack.append(streams[current_stream])
			streams[current_stream] = rng.randi_range(0, len(piece_types) - 1)
			using_utility = false
			$HUD.update_options(len(stack))
	elif Input.is_action_just_pressed("Retrieve"):
		if stack.size() > 0:
			$HUD.update_options(len(stack), 4)
			using_stack_piece = true
			using_utility = false
	elif Input.is_action_just_pressed("Utility"):
		if utility_usage < MAX_UTILITES:
			using_utility = true
			using_stack_piece = false
			$HUD.update_options(len(stack), 5)
	#elif Input.is_action_just_pressed("Utility"):
		#using_utility = true
		#using_stack_piece = false
		#$HUD.update_options(len(stack), 5)
		
func _handle_piece_movement() -> void:
	var move_delta := Vector3.ZERO
	
	# Get camera's direction (normalized for safety)
	var cam_pos = $Camera3D.position.normalized()

	# Determine primary axis (which axis camera is most aligned with)
	var forward = Vector3.ZERO
	if abs(cam_pos.x) < abs(cam_pos.z):
		# Camera more aligned with Z axis
		forward = Vector3(0, 0, -sign(cam_pos.z))
	else:
		# Camera more aligned with X axis
		forward = Vector3(-sign(cam_pos.x), 0, 0)

	# Derive other directions
	var backward = -forward
	var right = Vector3(-forward.z, 0, forward.x)  # Rotate forward 90° clockwise
	var left = -right

	# Apply based on input
	if Input.is_action_just_pressed("Forward"):
		move_delta = forward
	elif Input.is_action_just_pressed("Backward"):
		move_delta = backward
	elif Input.is_action_just_pressed("Left"):
		move_delta = left
	elif Input.is_action_just_pressed("Right"):
		move_delta = right
	
	if move_delta != Vector3.ZERO:
		_clear_piece_from_grid()
		current_pos += move_delta
		
		while current_pos in occupied_cells or $GridMap.get_cell_item(current_pos) == LAND:
			current_pos += Vector3(0, 1, 0)
			
		while current_pos[1] > 0 and ((current_pos - Vector3(0, 1, 0)) not in occupied_cells) and $GridMap.get_cell_item(current_pos - Vector3(0, 1, 0)) != LAND:
			current_pos -= Vector3(0, 1, 0)
			
func _handle_piece_rotation() -> void:
	if Input.is_action_just_pressed("Rotate Piece"):
		_clear_piece_from_grid()
		orientation += 1
			
func _handle_piece_placement() -> void:
	if not Input.is_action_just_pressed("Place"):
		return
	
	if _can_place_piece() and _has_support_below():
		var was_utility = using_utility
		_place_current_piece()
		if using_stack_piece:
			stack.pop_back()
			$HUD.update_options(len(stack))
			using_stack_piece = false
		if using_utility:
			utility_usage += 1
			$HUD.update_options(len(stack), 1, utility_usage)
			using_utility = false
		if not was_utility:
			_spawn_new_piece()
		
func _render_current_piece() -> void:
	var coords := _get_piece_coordinates(current_pos, orientation)
	
	for coord in coords:
		$GridMap.set_cell_item(coord, CP)
